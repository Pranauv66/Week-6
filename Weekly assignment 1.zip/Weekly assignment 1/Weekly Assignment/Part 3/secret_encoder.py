

message = input("Enter your secret message: ")

clean_message = ""
for letter in message.upper():
    if letter.isalpha() and letter.isascii():
        clean_message = clean_message + letter

numbers = []
for letter in clean_message:
    number = ord(letter) - ord("A") + 1
    numbers.append(str(number))

numbers.reverse()
secret_message = "-".join(numbers)

width = len(secret_message) + 4
print("*" * width)
print("* " + secret_message + " *")
print("*" * width)
