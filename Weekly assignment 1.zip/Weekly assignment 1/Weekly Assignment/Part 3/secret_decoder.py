

secret_message = input("Enter the secret numbers separated by hyphens: ").strip()

if secret_message:
    numbers = secret_message.split("-")
    numbers.reverse()

    message = ""
    valid_message = True

    for number in numbers:
        if number.isdigit() and 1 <= int(number) <= 26:
            letter = chr(int(number) + ord("A") - 1)
            message = message + letter
        else:
            valid_message = False
            break

    if valid_message:
        print("Original message:", message)
    else:
        print("Invalid code. Use numbers from 1 to 26 separated by hyphens.")
else:
    print("No secret message was entered.")
