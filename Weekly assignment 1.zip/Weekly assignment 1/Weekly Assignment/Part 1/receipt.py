shop_name = "Book Shop"
item1 = "Notebook"
price1 = 50
item2 = "Pen"
price2 = 10
item3 = "Pencil"
price3 = 5

total = price1 + price2 + price3

receipt = f"""
        {shop_name}
--------------------------------
{"Item":<20}{"Price":>8}
--------------------------------
{item1:<20}{price1:>8.2f}
{item2:<20}{price2:>8.2f}
{item3:<20}{price3:>8.2f}
--------------------------------
{"Total":<20}{total:>8.2f}
--------------------------------
Thank you for shopping!
"""


