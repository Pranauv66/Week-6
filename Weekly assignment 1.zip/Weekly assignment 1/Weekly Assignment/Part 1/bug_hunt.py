name = input("Enter your name: ")
age = input("Enter your age: ")

print("Hello" + name)
print("Next year you will be " + age + 1)
print("Your age in months:", age * 12)

number1 = input("Enter first number: ")
number2 = input("Enter second number: ")

print("Total:", number1 + number2)

if age >= 18:
    print("You are an adult")
else:
    print("You are a minor")
