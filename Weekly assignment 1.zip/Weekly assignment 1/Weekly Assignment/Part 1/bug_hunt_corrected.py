name = input("Enter your name: ").strip()
age = int(input("Enter your age: "))

print("Hello", name)
print("Next year you will be", age + 1)
print("Your age in months:", age * 12)

number1 = int(input("Enter first number: "))
number2 = int(input("Enter second number: "))

print("Total:", number1 + number2)

if age >= 18:
    print("You are an adult")
else:
    print("You are a minor")
