age = int(input("Enter your age in years: "))

if age >= 0:
    months = age * 12
    days = age * 365
    weeks = days / 7
    hours = days * 24

    print("\nLIFE IN NUMBERS")
    print("-" * 35)
    print("Unit\t\tValue")
    print("-" * 35)
    print(f"Months\t\t{months}")
    print(f"Weeks\t\t{weeks:.2f}")
    print(f"Days\t\t{days}")
    print(f"Hours\t\t{hours}")
    print("-" * 35)
else:
    print("Age cannot be negative.")

