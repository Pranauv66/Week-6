
name = input("Enter your full name: ")

name = name.strip().lower()
name = " ".join(name.split())
parts = name.split()

if len(parts) >= 2:
    first_name = parts[0]
    last_name = parts[-1]
    email = first_name + "." + last_name + "@acmelabs.com"

    initials = ""
    for word in parts:
        initials = initials + word[0].upper()

    print("Name:", name.title())
    print("Email:", email)
    print("Initials:", initials)
else:
    print("Please enter at least a first name and a last name.")
