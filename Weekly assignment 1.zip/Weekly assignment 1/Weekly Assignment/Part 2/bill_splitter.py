

bill = float(input("Enter the bill amount: "))
tip_percent = float(input("Enter tip percentage: "))
people = int(input("Enter number of people: "))

if bill >= 0 and tip_percent >= 0 and people > 0:
    tip = bill * tip_percent / 100
    total = bill + tip
    share = total / people

    print("\n----- BILL DETAILS -----")
    print(f"Bill Amount: Rs. {bill:.2f}")
    print(f"Tip Amount: Rs. {tip:.2f}")
    print(f"Total Bill: Rs. {total:.2f}")
    print(f"Each Person Pays: Rs. {share:.2f}")
else:
    print("Please enter valid values.")
